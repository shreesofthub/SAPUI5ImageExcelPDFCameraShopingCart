sap.ui.define([
    "sap/ui/core/mvc/Controller"
    
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller) {
		"use strict";

		return Controller.extend("ns.businesspartners.controller.suppliers", {
            // formatter:formatter,
			onInit: function () {
                this.oRouter = this.getOwnerComponent().getRouter();
            },
            onItemSelection:function(event){
                var listItem = event.getParameter("listItem");
                var sPath = listItem.getBindingContextPath();
                var index = sPath.split("/")[sPath.split("/").length - 1];
                this.oRouter.navTo("detailSupplier",{
                    id:index
                }); 
            }
		});
	});
