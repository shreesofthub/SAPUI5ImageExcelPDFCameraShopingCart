sap.ui.define([
	"ns/businesspartners/test/unit/controller/suppliers.controller"
], function () {
	"use strict";
});
